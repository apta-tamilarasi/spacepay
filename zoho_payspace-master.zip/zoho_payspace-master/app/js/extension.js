let orgDetails = {};
let psCredential = {}
let navLink = document.getElementsByClassName("nav-link")
let navSec = document.getElementsByClassName("nav-sec")
let calendarValue = document.getElementById('calendar')
let companyId = document.getElementById("companyId")
let sec1Div = document.getElementsByClassName("sec1")
let note = document.getElementById("note")
let payslip = []
let monthForPayslip
let yearForPayslip
let employees = []
let payspaceToken=""
let journalCustomId=""
let expenseCustomId=""

window.onload = function () {
    ZFAPPS.extension.init().then(function (App) {
        ZFAPPS.get("organization")
            .then(async function (data) {
                orgDetails.dc = data.organization.api_root_endpoint;
                orgDetails.orgId = data.organization.organization_id;
                await pageNav(0)
                await customFieldGet()
                await chartOfAccountGet()
                await payspaceCredentialGet()

            })
            .catch(function (err) {
                console.error(err);
            });
    });
};

const createMapping = async () => {

    await journalCustomGet("", 1)
    if (calendarValue.value != "" && companyId.value != "" && note.value != '' && isNewJournal) {
        document.getElementById('nextButton').disabled = true
        document.getElementById('buttonText').textContent = 'Wait...';
        document.getElementById('loadingSpinner').style.display = 'inline-block';

        const [monthName, year] = calendarValue.value.split('-');

        const monthMap = {
            January: 1,
            February: 2,
            March: 3,
            April: 4,
            May: 5,
            June: 6,
            July: 7,
            August: 8,
            September: 9,
            October: 10,
            November: 11,
            December: 12
        };
        monthForPayslip = monthMap[monthName]
        yearForPayslip = year
        await glGet(monthMap[monthName], year, companyId.value)
        await getPayslip(`https://api.payspace.com/odata/v1.1/${companyId.value}/EmployeePayslip/${year}/${monthMap[monthName]}`, page = 1)

    }
    else {
        if (calendarValue.value === "" || companyId.value === "" || note.value === '') {
            ShowNotification("error", "Field cannot be empty")
        }
        else if (!isNewJournal) {
            ShowNotification("error", "The selected payrun date already has an associated journal entry. Please choose a different date.");
        }

    }

}

const pageNav = async (index) => {
    let notification = document.getElementById("user-notify")
    notification.style.display = "none"
    document.getElementById("next-div").style.display = "none"

    sec1Div[0].style.display = "block";
    sec1Div[1].style.display = "none";
    recordDiv.style.display = "none";
    document.getElementById("warning").style.display = "none"
    companyId.value = ""
    calendarValue.value = ''
    note.value = ''
    jSuites.calendar(document.getElementById('calendar')).reset()
    document.getElementById('companyId').addEventListener('input', function (e) {
        this.value = this.value.replace(/[^0-9]/g, '');
    });
    jSuites.calendar(document.getElementById('calendar'), {
        type: 'year-month-picker',
        format: 'MMMM-YYYY',
    });
    document.getElementById('calendar').value = ""
    document.getElementById('calendar').setAttribute('placeholder', 'Pick your journal Date');

    for (let i = 0; i < navSec.length; i++) {
        if (index === i) {
            navSec[i].style.display = "block"
            navLink[i].setAttribute("class", "nav-link active")
        }
        else {
            navSec[i].style.display = "none"
            navLink[i].setAttribute("class", "nav-link")
        }
    }
    if (index === 1) {
        document.getElementById("waitingMessage").style.display = "block";
        document.getElementById("waitingMessage").innerHTML = "Fetching... Please wait"
        await journalCustomGet("record", 1)
    }
}


const ShowNotification = (type, message) => {
    ZFAPPS.invoke("SHOW_NOTIFICATION", {
        type,
        message
    }).catch((er) => {
        console.error(er);
    });
};

const dateCheck = async () => {
    const calendarInput = document.getElementById('calendar');
    let notification = document.getElementById("user-notify")
    notification.style.display = "none"
    document.getElementById("nextButton").style.visibility = "hidden"
    document.getElementById("next-div").style.display = "none"

    if (calendarInput.value != "") {
        const monthMap = {
            January: 1,
            February: 2,
            March: 3,
            April: 4,
            May: 5,
            June: 6,
            July: 7,
            August: 8,
            September: 9,
            October: 10,
            November: 11,
            December: 12
        };


        document.getElementById("nextButton").style.visibility = "visible"
        document.getElementById("next-div").style.display = "block"

        const [monthName, year] = calendarInput.value.split('-');
        const currentDate = new Date();
        const currentMonth = currentDate.getMonth() + 1;
        const currentYear = currentDate.getFullYear();
        const selectedMonth = monthMap[monthName]

        if (year > currentYear || (year == currentYear && selectedMonth >= currentMonth)) {
            notification.innerHTML = "Select a closed period (previous month). The current or future periods are not allowed"
            notification.style.display = "block"
            companyId.value = ""
            document.getElementById("nextButton").style.visibility = "hidden"
            document.getElementById("next-div").style.display = "none"
        }
        else {

            companyId.value != "" ? await journalCheck() : ""
        }
    }
    else {
        companyId.value = ""
        ShowNotification("error", "Please select a valid date")
    }

}
const journalCheck = async () => {

    if (companyId.value != "") {
        const monthMap = {
            January: "01",
            February: "02",
            March: "03",
            April: "04",
            May: "05",
            June: "06",
            July: "07",
            August: "08",
            September: "09",
            October: "10",
            November: "11",
            December: "12"
        };
        const calendarInput = document.getElementById('calendar');
        const [monthName, year] = calendarInput.value.split('-');
        let notification = document.getElementById("user-notify")

        await allJournalGet()

        let isRecord = allRecord.find((re) => {
            let splitDate = (re.journal_date).split("-")
            let ref = (re.reference_number).split("-")
            return `Pay Space-${companyId.value}` === `${ref[0]}-${ref[1]}` && monthMap[monthName] == splitDate[1] && year == splitDate[0]
        })

        if (isRecord) {
            notification.innerHTML = "The selected payrun date already has an associated journal entry. Please choose a different date."
            notification.style.display = "block"
            document.getElementById("nextButton").style.visibility = "hidden"
        }
        else {
            notification.style.display = "none"
            document.getElementById("nextButton").style.visibility = "visible"

        }
    }


}


let customFieldGet= async () => {
    let fields=["journal","expense"]
    fields.map((field)=>{
        let account = {
            url: `${orgDetails.dc}/settings/fields?entity=${field}&organization_id=${orgDetails.orgId}`,
            method: "GET",
            connection_link_name: "payspacezohobook"
        };
        ZFAPPS.request(account)
            .then(function (value) {
                let accounts = JSON.parse(value.data.body)
               let acc=accounts.fields.filter((cus)=>{
                
                return field==="journal"?cus.field_name==="cf__com_fefs5u_journal_created_from":cus.field_name==="cf__com_fefs5u_expense_created_from"
               })
               field==="journal"?journalCustomId=acc[0].field_id: expenseCustomId=acc[0].field_id
               
    
            })
            .catch(function (err) {
                console.error(err)
            });

    })
};

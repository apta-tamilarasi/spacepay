let debitCreditDiv = document.getElementsByClassName("debitcredit")

let glGet = async (month, year, companyid) => {
    
    let custom = {
        url: `https://api.payspace.com/odata/v1.1/${companyid}/CompanyGeneralLedger/${year}/${month}?groupingCode=2`,
        method: "GET",
        header: [
            { key: "Authorization", value:`Bearer ${payspaceToken}` },
            { key: "content-Type", value: "application/json" }
        ]
    };
    ZFAPPS.request(custom)
        .then(async function (value) {
          
           if(value.data.status_code==401){
            await payspaceCredentialGet()
            await glGet(month, year, companyid)
           }
           else{
            try {
                let responseJSON = value.data.body;
                await glExtractionGet(companyid, JSON.parse(responseJSON).ExtractionId)
            }
            catch (err) {
                console.error(err);
                document.getElementById('nextButton').disabled = false
                document.getElementById('buttonText').textContent = 'Next';
                document.getElementById('loadingSpinner').style.display = 'none';
                ShowNotification("error", err)
            }
           }
        })
        .catch(function (err) {
            console.error("err", err);
        });
};




let glExtractionGet = async (companyId, extractionId) => {
    let custom = {
        url: `https://api.payspace.com/odata/v1.1/${companyId}/CompanyGeneralLedger/${extractionId}/status`,
        method: "GET",
        header: [
            { key: "Authorization", value: `Bearer ${payspaceToken}` },
            { key: "content-Type", value: "application/json" }
        ]
    };
    ZFAPPS.request(custom)
        .then(async function (value) {
            
            try {
                let responseJSON = value.data.body;
                
                if (JSON.parse(responseJSON).Status === "Completed") {
                    await getGeneralLedge(JSON.parse(responseJSON).DownloadUrl)
                }
                else if (JSON.parse(responseJSON).Status === "Error") {
                    document.getElementById('nextButton').disabled = false
                    document.getElementById('buttonText').textContent = 'Next';
                    document.getElementById('loadingSpinner').style.display = 'none';
                    ShowNotification("error",JSON.parse(responseJSON).Error)
                }
                else {
                    setTimeout(async () => {
                        await glExtractionGet(companyId, extractionId)
                    }, 4000)

                }

            }
            catch (err) {
                document.getElementById('nextButton').disabled = false
                document.getElementById('buttonText').textContent = 'Next';
                document.getElementById('loadingSpinner').style.display = 'none';
                console.error(err);
                ShowNotification("error", err)
            }
        })
        .catch(function (err) {
            document.getElementById('nextButton').disabled = false
            document.getElementById('buttonText').textContent = 'Next';
            document.getElementById('loadingSpinner').style.display = 'none';
            console.error("err", err);
            ShowNotification("error", err)

        });
};

const getGeneralLedge = async (path) => {
    debitCreditDiv[0].innerHTML = ''
    debitCreditDiv[1].innerHTML = ''
    let custom = {
        url:path,
        method: "GET"
    };
    
    ZFAPPS.request(custom)
        .then(async function (value) {

            try {
                let responseJSON = value.data.body;
                
                if (JSON.parse(responseJSON).GeneralLedgerLines.length > 0) {
                    await fieldmapCustomGet(JSON.parse(responseJSON).GeneralLedgerLines)

                }
                else {
                    document.getElementById('nextButton').disabled = false
                    document.getElementById('buttonText').textContent = 'Next';
                    document.getElementById('loadingSpinner').style.display = 'none';
                    ShowNotification("error", "GeneralLegder is not available for the period")
                }
            }
            catch (err) {
                document.getElementById('nextButton').disabled = false
                document.getElementById('buttonText').textContent = 'Next';
                document.getElementById('loadingSpinner').style.display = 'none';
                console.error("err", err);
                ShowNotification("error", err)
            }
        })
        .catch(function (err) {
            document.getElementById('nextButton').disabled = false
            document.getElementById('buttonText').textContent = 'Next';
            document.getElementById('loadingSpinner').style.display = 'none';
            console.error("err", err);
            ShowNotification("error", err)
        });

}



let getPayslip = async (path, page = 1) => {

    page === 1 ? payslip = [] : ""
    try {
        let custom = {
            url: path,
            method: "GET",
            header: [
                { key: "Authorization", value: `Bearer ${payspaceToken}` },
                { key: "content-Type", value: "application/json" }
            ]
        };
        ZFAPPS.request(custom)
            .then(async function (value) {
                try {
                    let responseJSON = value.data.body;
                    payslip = [...JSON.parse(responseJSON).value, ...payslip]
                    if (JSON.parse(responseJSON)["@odata.nextLink"]) {
                        page = page + 1
                        await getPayslip(JSON.parse(responseJSON)["@odata.nextLink"], page)

                    }
                }
                catch (err) {
                    console.error(err);
                    ShowNotification("error", "payslip not found")
                }
            })
            .catch(function (err) {
                console.error("err", err);
            });

    }
    catch (err) {
        console.error(err);

    }
};

const getEmployee = async (path) => {
    let client = {
        url: path,
        method: "GET",
        header: [
            { key: "Authorization", value:`Bearer ${payspaceToken}` },
            { key: "content-Type", value: "application/json" }
        ]
    };

    try {
        
        await ZFAPPS.request(client).then(function (value) {
            
        let response = value.data.body;
        let employees = JSON.parse(response).value;
        
        
        return employees;

        }).catch (function(err) {
            console.error("Error while fetching employee data");
            return null
        })
        
    } catch (err) {
        console.error("Error while fetching employee data");
        return null
    }

    
};


let mapping = async (payrunDetails) => {
    let generalLedgerLines = payrunDetails;
    payAccount[0].textContent = ""

    let selectedOption = document.createElement("option")
    selectedOption.textContent = "Choose a ZB Bank account"
    selectedOption.value = ''
    selectedOption.selected = true
    payAccount[0].appendChild(selectedOption)

    for (let i = 0; i < debitCreditDiv.length; i++) {
        debitCreditDiv[i].innerHTML = ''
    }

    bank.map((b) => {
        let option = document.createElement("option")
        option.textContent = b.account_name
        option.value = b.account_id
        if (mappingDatas.length > 0) {
            mappingDatas.map((data) => {
                (data.label_name === "bank") && (data.zb_account === b.account_id) ? option.selected = true :
                    data.label_name === "journal_type" ? data.zb_account === "published" ? transactionType[3].checked = true : transactionType[2].checked = true :
                        data.label_name === "transaction_type" ? data.zb_account === "group" ? transactionType[1].checked = true : transactionType[0].checked = true : selectedOption.selected = false
            })
        }
        payAccount[0].appendChild(option)
    })
    generalLedgerLines.map((g) => {

        var div = document.createElement('div');
        div.className = 'input-group mb-3';
        var label = document.createElement('label');
        label.className = 'input-group-text mapping-label';
        label.setAttribute('for', 'inputGroupSelect01');
        label.textContent = g.Description !== "" ? g.Description : `${g.GeneralLedgerAccountNumber}`;

        var select = document.createElement('select');
        select.className = 'form-select mappingform';
        select.id = 'inputGroupSelect01';
        var option = document.createElement('option');
        option.selected = true;
        option.textContent = 'Choose ZB Account';
        option.value = ""
        select.appendChild(option);
        div.appendChild(label);
        div.appendChild(select);
        let isMapped = false;

        if (g.DebitOrCredit === "DR") {
            expense.map((e) => {
                g.zbaccountid = e.account_id
                var option = document.createElement('option');
                option.textContent = e.account_name
                if (mappingDatas.length > 0) {
                    mappingDatas.find((data) => {
                        if (data.label_name === `debit_${g.Description}` && data.zb_account === e.account_id) {
                            option.selected = true;
                            isMapped = true;
                        }
                    });
                }
                option.value = JSON.stringify(g)
                select.appendChild(option);

            })
            isMapped ? debitCreditDiv[2].appendChild(div) : debitCreditDiv[3].appendChild(div);

        }
        else if (g.DebitOrCredit === "CR") {

            income.map((inc) => {
                g.zbaccountid = inc.account_id
                var option = document.createElement('option');
                option.textContent = inc.account_name

                if (mappingDatas.length > 0) {
                    mappingDatas.find((data) => {
                        if (data.label_name === `credit_${g.Description}` && data.zb_account === inc.account_id) {
                            option.selected = true;
                            isMapped = true;
                        }
                    });
                }
                option.value = JSON.stringify(g)
                select.appendChild(option);
            })
            isMapped ? debitCreditDiv[0].appendChild(div) : debitCreditDiv[1].appendChild(div);
        }

    })
    document.getElementById('nextButton').disabled = false
    document.getElementById('buttonText').textContent = 'Next';
    document.getElementById('loadingSpinner').style.display = 'none';

    sec1Div[0].style.display = "none";
    sec1Div[1].style.display = "block";

};



const payspaceCredentialGet = async () => {
    try {
        let customId = {
            url: `${orgDetails.dc}/settings/orgvariables/vl__com_fefs5u_client_id?organization_id=${orgDetails.orgId}`,
            method: "GET",
            connection_link_name: "payspacezohobook",
        };

        let responseId = await ZFAPPS.request(customId);
        let dataId = JSON.parse(responseId.data.body);

        let clientId = dataId.orgvariable?.value


        let customSecret = {
            url: `${orgDetails.dc}/settings/orgvariables/vl__com_fefs5u_client_secret?organization_id=${orgDetails.orgId}`,
            method: "GET",
            connection_link_name: "payspacezohobook",
        };

        let responseSecret = await ZFAPPS.request(customSecret);
        let dataSecret = JSON.parse(responseSecret.data.body);

        let clientSecret = dataSecret.orgvariable?.value

        await getPayspaceToken(clientId, clientSecret)

    } catch (err) {
        console.error("Error in client id and client secret:", err);
    }
}


const getPayspaceToken = async (clientId, clientSecret) => {
    let tokenRequest = {
        url: "https://identity.yourhcm.com/connect/token",
        method: "POST",
        body: {
            mode: "urlencoded",
            urlencoded: [
                { key: "client_id", value: clientId },
                { key: "client_secret", value: clientSecret},
                { key: "scope", value: "api.full_access" }
            ]
        },
        headers: [{
            key: "Content-Type", value: "application/x-www-form-urlencoded"
        }]
    }

    ZFAPPS.request(tokenRequest)
        .then(async function (tokenResponse) {
            let tokenData = JSON.parse(tokenResponse.data.body);
           tokenData.error?  ShowNotification("error",`Payspace-${tokenData.error}`): await tokenStore(tokenData)
        })
        .catch((err) => {
            console.error("Error during token request:", err);
            ShowNotification("error",`Payspace-${tokenData.err}`)
        });
}

const tokenStore = async (tokenResponse) => {
    try {
        payspaceToken = tokenResponse.access_token
        

        let company = document.getElementById("companyId")
        company.innerHTML = ""

        let selectedOption = document.createElement("option");
        selectedOption.textContent = "Select the Company";
        selectedOption.value = '';
        selectedOption.selected = true;
        company.appendChild(selectedOption);

        const allCompanies = tokenResponse.group_companies.flatMap(group => group.companies);


        allCompanies.forEach((com) => {
            let option = document.createElement("option");
            option.textContent = com.company_name
            option.value = com.company_id;
            company.appendChild(option);
        });

    } catch (err) {
        console.error("Error in token get error:", err);
    }

}

let income = []
let expense = []
let bank = []
let records = []


let newRecord = []
let recordDiv = document.getElementById("recorddiv")
let currencyInput = document.getElementById("currency")
let bankName = document.getElementById("bankname")
let payAccount = document.getElementsByClassName("payment-account")
let transactionType = document.getElementsByClassName("form-check-input")
let nettPayAccount = ''
let mappingDatas = []
let isNewJournal = true

let chartOfAccountGet = async () => {
    let account = {
        url: `${orgDetails.dc}/chartofaccounts?organization_id=${orgDetails.orgId}`,
        method: "GET",
        connection_link_name: "payspacezohobook",
    };
    ZFAPPS.request(account)
        .then(function (value) {
            income = []
            expense = []
            bank = []
            let accounts = JSON.parse(value.data.body)
            accounts.chartofaccounts.map((acc) => {
                if (acc.is_active === true) {
                    if (acc.account_type === "expense") {
                        expense.push(acc)
                    }

                    else if (acc.account_type === "other_current_liability") {
                        income.push(acc)
                    }
                    else if (acc.account_type === "bank") {
                        bank.push(acc)
                    }
                }
            })
        })
        .catch(function (err) {
            console.error("chartof account request failed", err);
        });
};

const journalCustomGet = async (type) => {
    try {
        records = []
        await allJournalGet()
        records = allRecord.filter((re) => {
            return re.reference_number.includes("Pay Space");
        });

        if (records.length !== 0) {
            if (type === "record") {
                await pagination(records)
            }
            else {
                isNewJournal = true
                const [monthName, year] = calendarValue.value.split('-');

                const monthMap = {
                    January: "01",
                    February: "02",
                    March: "03",
                    April: "04",
                    May: "05",
                    June: "06",
                    July: "07",
                    August: "08",
                    September: "09",
                    October: "10",
                    November: "11",
                    December: "12"
                };
                records.find((re) => {
                    let splitDate = (re.journal_date).split("-")
                    let ref = (re.reference_number).split("-")

                    if (`Pay Space-${companyId.value}` === `${ref[0]}-${ref[1]}` && monthMap[monthName] == splitDate[1] && year == splitDate[0]) {
                        isNewJournal = false
                    }

                })
            }

        }
        else {
            if (type === "record") {
                document.getElementById("waitingMessage").style.display = "none";
                document.getElementById("warning").style.display = "block"
                recordDiv.style.display = "none";
                ShowNotification("error", `Journal Record is not available, Create new journal`)

            }
        }
    }
    catch (err) {
        console.error("err", err);
    }
}
const pagination = async (records) => {
    newRecord = records
    document.getElementById("waitingMessage").style.display = "none";
    document.getElementById("warning").style.display = "none";

    const objects = newRecord;
    let currentPage = 1;
    const itemsPerPage = 10;

    if (newRecord.length > 0) {
        function displayObjects(page) {
            const objectList = document.getElementById('records');
            objectList.innerHTML = '';
            const start = (page - 1) * itemsPerPage;
            const end = start + itemsPerPage;
            const paginatedObjects = objects.slice(start, end);

            paginatedObjects.forEach((obj, i) => {
                const row = document.createElement('tr');
                row.style.position = 'relative';

                const no = document.createElement('td');
                no.textContent = start + i + 1;
                let companyId = obj.reference_number.split("-")
                const company = document.createElement('td');
                company.textContent = companyId[1];


                const idCell = document.createElement('td');
                idCell.textContent = obj.journal_date;

                const note = document.createElement('td');
                note.textContent = obj.notes;

                const total = document.createElement('td');
                total.textContent = obj.total;

                row.appendChild(no);
                row.appendChild(company);
                row.appendChild(idCell);
                row.appendChild(note);
                row.appendChild(total);
                objectList.appendChild(row);
            });
            recordDiv.style.display = "block";
            renderPaginationButtons();
        }

        function renderPaginationButtons() {
            const totalPages = Math.ceil(objects.length / itemsPerPage);
            const paginationDiv = document.getElementById('pagination');
            paginationDiv.innerHTML = '';

            const prevButton = document.createElement('button');
            prevButton.textContent = '<<';
            prevButton.classList.add('btn-primary', 'mr-2');
            prevButton.disabled = currentPage === 1;

            prevButton.onclick = () => changePage(currentPage - 1);
            paginationDiv.appendChild(prevButton);
            if (currentPage === 1) {
                prevButton.style.cursor = 'not-allowed';
            }

            const pageButton = document.createElement('button');
            pageButton.textContent = currentPage;
            pageButton.classList.add('btn-secondary', 'mr-2');
            pageButton.disabled = true;
            paginationDiv.appendChild(pageButton);

            const nextButton = document.createElement('button');
            nextButton.textContent = '>>';
            nextButton.classList.add('btn-primary');
            nextButton.disabled = currentPage === totalPages;

            nextButton.onclick = () => changePage(currentPage + 1);
            paginationDiv.appendChild(nextButton);
            if (currentPage === totalPages) {
                nextButton.style.cursor = 'not-allowed';
            }

            paginationDiv.style.display = totalPages === 1 ? 'none' : 'block';
        }

        function changePage(page) {
            currentPage = page;
            displayObjects(currentPage);
        }

        displayObjects(currentPage);
    }
    else {
        recordDiv.style.display = "none";
        document.getElementById("waitingMessage").style.display = "none";
        document.getElementById("warning").style.display = "block"
        ShowNotification("error", `Journal Record is not available, Create new journal`)

    }
};


const createJournal = async () => {
    nettPayAccount = ''
    let mappingLabel = document.getElementsByClassName("mapping-label")
    document.getElementById('nextButton2').disabled = true
    document.getElementById('buttonText2').textContent = 'Creating... ';
    document.getElementById('loadingSpinner2').style.display = 'block';

    const journalData = {
        "notes": `${note.value}`,
        "status": transactionType[2].checked === true ? "draft" : "published",
        "custom_fields": [
            {
                "customfield_id": journalCustomId,
                "value": "payspace"
            }
        ],
        "line_items": []
    }
    let isEmpty = false
    const mapping = document.getElementsByClassName("mappingform")

    for (let i = 0; i < mapping.length; i++) {
        if (i === 0 && mapping[1].value !== "") {
            journalData.journal_date = JSON.parse(mapping[i].value).PeriodEndDate
            journalData.reference_number = `Pay Space-${companyId.value}-${JSON.parse(mapping[i].value).PeriodEndDate}`
        }
        mapping[i].value !== "" && JSON.parse(mapping[i].value).DebitOrCredit === "CR" ? mappingLabel[i].textContent === "Net Pay" && mapping[i].value !== "" && nettPayAccount === '' ? nettPayAccount = mapping[i].value : "" : ""

        if (mapping[i].value === "") {
            isEmpty = true
            break
        }
    }
    payAccount[0].value === "" ? isEmpty = true : ''
    if (!isEmpty) {
        await storeFieldMapping(mappingLabel, mapping)

        for (let i = 0; i < mapping.length; i++) {
           if(JSON.parse(mapping[i].value).Amount>0){
             if (JSON.parse(mapping[i].value).DebitOrCredit === "DR") {
                journalData.line_items.push({
                    "account_id": JSON.parse(mapping[i].value).zbaccountid,
                    "debit_or_credit": "debit",
                    "amount": JSON.parse(mapping[i].value).Amount,
                    "description": JSON.parse(mapping[i].value).Description !== null ? JSON.parse(mapping[i].value).Description : JSON.parse(mapping[i].value).GeneralLedgerAccountNumber
                })
            }
            else if (JSON.parse(mapping[i].value).DebitOrCredit === "CR") {
                journalData.line_items.push({
                    "account_id": JSON.parse(mapping[i].value).zbaccountid,
                    "debit_or_credit": "credit",
                    "amount": JSON.parse(mapping[i].value).Amount,
                    "description": JSON.parse(mapping[i].value).Description !== null ? JSON.parse(mapping[i].value).Description : JSON.parse(mapping[i].value).GeneralLedgerAccountNumber
                })

            }}
        }

        let journal = {
            url: `${orgDetails.dc}/journals?organization_id=${orgDetails.orgId}`,
            method: "POST",
            body: {
                mode: "raw",
                raw: journalData,
            },
            connection_link_name: "payspacezohobook",
        };
        await ZFAPPS.request(journal)
            .then(async function (value) {
                
                let responseJSON = JSON.parse(value.data.body);
                
                if (responseJSON.code === 0) {
                    calendarValue.value = ''
                    note.value = ''
                    jSuites.calendar(document.getElementById('calendar')).reset()
                    document.getElementById('companyId').addEventListener('input', function (e) {
                        this.value = this.value.replace(/[^0-9]/g, '');
                    });

                    jSuites.calendar(document.getElementById('calendar'), {
                        type: 'year-month-picker',
                        format: 'MMMM-YYYY',
                    });
                    
                    document.getElementById('calendar').value = ""
                    document.getElementById('calendar').setAttribute('placeholder', 'Pick your journal Date');

                    await createEmployeeTransaction()
                    document.getElementById('nextButton2').disabled = false
                    document.getElementById('buttonText2').textContent = 'Create Journal';
                    document.getElementById('loadingSpinner2').style.display = 'none';

                    debitCreditDiv[0].innerHTML = ''
                    debitCreditDiv[1].innerHTML = ''

                    sec1Div[0].style.display = "block";
                    sec1Div[1].style.display = "none";
                    companyId.value = ''
                    ShowNotification("success", "Journal created successfully")
                    document.getElementById("nextButton").style.visibility = "hidden"
                    document.getElementById("next-div").style.display = "none"

                }
                else {
                    document.getElementById('nextButton2').disabled = false
                    document.getElementById('buttonText2').textContent = 'Create Journal';
                    document.getElementById('loadingSpinner2').style.display = 'none';
                    ShowNotification("error", `${responseJSON.message}`)
                }

            })

            .catch(function (err) {
                console.error("err", err);
            });
    }
    else {
        document.getElementById('nextButton2').disabled = false
        document.getElementById('buttonText2').textContent = 'Create Journal';
        document.getElementById('loadingSpinner2').style.display = 'none';
        ShowNotification("error", `Please Map all Account`)

    }
}


const createEmployeeTransaction = async () => {
    let type = ''
    transactionType[0].checked === true ? type = "individual" : type = "group"

    if (type === "group") {
        let data = {
            "transaction_type": "expense",
            "account_id": JSON.parse(nettPayAccount).zbaccountid,
            "paid_through_account_id": payAccount[0].value,
            "date": JSON.parse(nettPayAccount).PeriodEndDate,
            "amount": JSON.parse(nettPayAccount).Amount,
            "description": `PaySpace - All employees payment`,
            "custom_fields": [
                {
                    "customfield_id": expenseCustomId,
                    "value": "payspace"
                }
            ],
            "reference_number": `payspace -${companyId.value}-${JSON.parse(nettPayAccount).PeriodEndDate}`,

        }

        await createExpense(data)
    }
    else {
        for (const ps of payslip) {
            if (ps.NetPay > 0) {
                let id = companyId.value;
                const employeeFilter = encodeURIComponent(`EmployeeNumber eq '${ps.EmployeeNumber}'`);
                let employee = ps.EmployeeNumber
                    ? await getEmployee(`https://api.payspace.com/odata/v1.1/${companyId.value}/Employee?$filter=${employeeFilter}`)
                    : null;
        
                let data = {
                    "account_id": JSON.parse(nettPayAccount).zbaccountid,
                    "paid_through_account_id": payAccount[0].value,
                    "date": JSON.parse(nettPayAccount).PeriodEndDate,
                    "amount": ps.NetPay,
                    "custom_fields": [
                        {
                            "customfield_id": expenseCustomId,
                            "value": "payspace"
                        }
                    ],
                    "description": employee && employee.length > 0
                        ? `Employee - ${employee[0].FirstName} ${employee[0].LastName}`
                        : ps.EmployeeNumber
                            ? `Payspace Employee - ${ps.EmployeeNumber}`
                            : "Payspace Employee",
                    "reference_number": `payspace -${id}-${ps.CompanyRun}`,
                };
        
                await createExpense(data);
            }
        }        


    }
}


const createExpense = async (data) => {
    let journal = {
        url: `${orgDetails.dc}/expenses?organization_id=${orgDetails.orgId}`,
        method: "POST",
        body: {
            mode: "raw",
            raw: data,
        },
        connection_link_name: "payspacezohobook",
    };
    ZFAPPS.request(journal)
        .then(async function (value) {
            JSON.parse(value.data.body);
        })
        .catch((err) => {
            console.error(err);

        })
}


let fieldmapCustomPut = async (mappingData) => {
    try {
        let data = { value: JSON.stringify(mappingData) };

        let custom = {
            url: `${orgDetails.dc}/settings/orgvariables/vl__com_fefs5u_payspace_field_map?organization_id=${orgDetails.orgId}`,
            method: "PUT",
            body: { mode: "raw", raw: data },
            connection_link_name: "payspacezohobook",
        };

        let response = await ZFAPPS.request(custom);
        
        JSON.parse(response.data.body);
    } catch (err) {
        console.error("Error in fieldmapCustomPut:", err);
    }
};


let fieldmapCustomGet = async (payrunDetails) => {
    mappingDatas = []
    try {
        let custom = {
            url: `${orgDetails.dc}/settings/orgvariables/vl__com_fefs5u_payspace_field_map?organization_id=${orgDetails.orgId}`,
            method: "GET",
            connection_link_name: "payspacezohobook",
        };

        let response = await ZFAPPS.request(custom);
        let data = JSON.parse(response.data.body);
        let fieldmapData = data.orgvariable?.value ? JSON.parse(data.orgvariable.value) : [];

        mappingDatas = fieldmapData.length > 0 ? fieldmapData : [];

        await mapping(payrunDetails)

    } catch (err) {
        console.error("Error in fieldmapCustomGet:", err);
    }

}

const storeFieldMapping = async (mappingLabel, mapping) => {
    try {
        let mappingValue = [];
        for (let i = 0; i < mapping.length; i++) {
            let value = JSON.parse(mapping[i].value);
            let type = value.DebitOrCredit === "CR" ? "credit" : "debit"
            let data = {
                zb_account: value.zbaccountid,
                label_name: `${type}_${mappingLabel[i].textContent}`
            }
            mappingValue.push(data)
        }
        let label = [{ name: "bank", value: payAccount[0].value },
        { name: "transaction_type", value: transactionType[0].checked === true ? "individual" : "group" },
        { name: "journal_type", value: transactionType[2].checked === true ? "draft" : "published" }]

        for (let i = 0; i < label.length; i++) {
            let data = {
                zb_account: label[i].value,
                label_name: label[i].name
            }
            mappingValue.push(data)
        }

        mappingDatas.map((existingMap) => {
            let exists = mappingValue.find((val) => val.label_name === existingMap.label_name);
            if (!exists) {
                mappingValue.push(existingMap);
            }
        })

        await fieldmapCustomPut(mappingValue);
    }
    catch (err) {
        console.error(err);

    }
}


const allJournalGet = async (page = 1) => {
    if (page === 1) {
        allRecord = []
    }
    let custom = {
        url: `${orgDetails.dc}/journals?organization_id=${orgDetails.orgId}`,
        method: "GET",
        connection_link_name: "payspacezohobook"
    };
    await ZFAPPS.request(custom)
        .then(async function (value) {
            let responseJSON = JSON.parse(value.data.body)

            allRecord = [...responseJSON.journals, ...allRecord]
            page = page + 1;
            if (responseJSON.page_context.has_more_page === true) {
                await allJournalGet(page);
            }
        })
}